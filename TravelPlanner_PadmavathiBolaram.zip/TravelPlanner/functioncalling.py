

def get_chat_model_completions(messages):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo-0613",
        messages=messages,
       
          temperature=0, # this is the degree of randomness of the model's output
          max_tokens = 300
    )
    return response.choices[0].message["content"] 

functions=[ {
         "name": "findBestHotels",
         "description": "Find the best 5 hotels for a given destination",
         "parameters": {
         "type": "object",
         "properties": {
         "destination": {
         "type": "string",
          "description": "The desired travel destination"}}}} ] ,