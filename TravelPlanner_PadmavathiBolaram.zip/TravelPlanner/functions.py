import openai
import ast
import re
import pandas as pd
import json


def initialize_conversation():
    '''
    Returns a list [{"role": "system", "content": system_message}]
    '''

    
    delimiter = "####"
  
    
    example_user_req = {'Destination': 'Goa','Type of hotel': '5 star','Number of days': '3','Budget': '30000'}
    
    system_message = f"""
    
   "You are an intelligent travel iternary planner and your goal is to find travel destination with the days. Need to create a iternary out of it. If you not able to understand the destination you can give error meesage.
    
    
    You need to discover the best five hotels in a destination.
    You need to ask relevant questions and understand the user profile by analysing the user's responses.
    You final objective is to fill the values for the different keys ('Destination','Type of hotel','Number of days','Budget') in the python dictionary and be confident of the values.
    These key value pairs define the user's profile.
    The python dictionary looks like this {{'Destination': 'values','Type of hotel': 'values','Number of days': 'values','Budget': 'values'}}
 
    The values currently in the dictionary are only representative values. 
    
   

    To fill the dictionary, you need to have the following chain of thoughts:
    {delimiter} Thought 1: Ask a question to understand the user's profile and preference for destinations. \n
    If their preference for the destination is unclear. Ask another question to comprehend their preferences.
    You are trying to fill thealues of all the keys {{'Destination': 'values','Type of hotel': 'values','Number of days': 'values','Budget': 'values'}} in the python dictionary by understanding the user requirements.
    Identify the keys for which you can fill the values confidently using the understanding. \n
    Remember the instructions around the values for the different keys. 
    Answer "Yes" or "No" to indicate if you understand the requirements and have updated the values for the relevant keys. \n
    If yes, proceed to the next step. Otherwise, rephrase the question to capture their preference. \n{delimiter}

    {delimiter}Thought 2: Now, you are trying to fill the values for the rest of the keys which you couldn't in the previous step. 
    Remember the instructions around the values for the different keys. Ask questions you might have for all the keys to strengthen your understanding of the user's preferences.
    Answer "Yes"
    or "No" to indicate if you understood all the values for the keys and are confident about the same. 
    If yes, move to the next Thought. If no, ask question on the keys whose values you are unsure of. \n
    It is a good practice to ask question with a sound logic as opposed to directly citing the key you want to understand value for.{delimiter}

    {delimiter}Thought 3: Check if you have correctly updated the values for the different keys in the python dictionary. 
    If you are not confident about any of the values, ask clarifying questions. {delimiter}

    Follow the above chain of thoughts and only output the final updated python dictionary. \n


    {delimiter} Here is a sample conversation between the user and assistant:
    User: "Hi, I Would like to to know top 5 travel destinations with scenic beauty ."
    Assistant: "Great! you likely have great plans for visting great destinations .  You would need a serene place with beautiful surroundingshigs. May I know what kind of places do you primarily focus on? Are you looking for INDIA or abraod ? Understanding the specific type of editing work will help me tailor my recommendations accordingly. Let me know if my understanding is correct until now."
    User: "I primarily looking for destinations located in India."
    Assistant: "Thank you for providing that information.Do you prefer what type of Hotels to stay Five star or 3 star or lodge ?Understanding your preference will help determine the top 5 best hotels."
    User: "Yes, I'll prefer 5 star hotels"
    Assistant: "Thank you for the information.Do you have any budget range?"
    User: "Yes, 4000 INR to 7000 INR per day."
    Assistant:"Could you kindly let me know your budget for the laptop? This will help me find options that fit within your price range while meeting the specified requirements."
    User: "my max budget is 10 thousand inr per day"
    Assistant: "{example_user_req}"
    {delimiter}

    Start with a short welcome message and encourage the user to share their requirements. Do not start with Assistant: 
    """
    conversation = [{"role": "system", "content": system_message}]
    return conversation



def get_chat_model_completions(messages):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        temperature=0, # this is the degree of randomness of the model's output
        max_tokens = 300
    )
    return response.choices[0].message["content"]


def moderation_check(user_input):
    response = openai.Moderation.create(input=user_input)
    moderation_output = response["results"][0]
    if moderation_output["flagged"] == True:
        return "Flagged"
    else:
        return "Not Flagged"



    
def intent_confirmation_layer(response_assistant):
    delimiter = "####"
    prompt = f"""
    You are an intelligent travel iternary planner who has an eye for detail.
    You are provided an input. You need to evaluate if the input has the following keys: 'GPU intensity','Display quality','Portability','Multitasking',' Processing speed','Budget'
    Next you need to evaluate if the keys have the the values filled correctly.
    The values for all keys, except 'budget', should be 'low', 'medium', or 'high' based on the importance as stated by user. The value for the key 'budget' needs to contain a number with currency.
    Output a string 'Yes' if the input contains the dictionary with the values correctly filled for all keys.
    Otherwise out the string 'No'.

    Here is the input: {response_assistant}
    Only output a one-word string - Yes/No.
    """


    confirmation = openai.Completion.create(
                                    model="gpt-3.5-turbo-instruct",
                                    prompt = prompt,
                                    temperature=0)


    return confirmation["choices"][0]["text"]




def dictionary_present(response):
    delimiter = "####"
    user_req = {'Destination': 'Goa','Type of hotel': 'five star','Number of days': '3','Budget': '30000'}
    
    prompt = f"""You are a python expert. You are provided an input.
            You have to check if there is a python dictionary present in the string.
            It will have the following format {user_req}.
            Your task is to just extract and return only the python dictionary from the input.
            The output should match the format as {user_req}.
            The output should contain the exact keys and values as present in the input.

            Here are some sample input output pairs for better understanding:
            {delimiter}
           
            input: {{'Destination': 'Goa','Type of hotel': 'five star','Number of days': '3','Budget': '30000'}}
            output:{{'Destination': 'Goa','Type of hotel': 'five star','Number of days': '3','Budget': '30000'}}

            input: Here is your user profile 'Destination': 'Gokarna','Type of hotel': 'five star','Number of days': '1','Budget': '10000'               output: {{'Destination': 'Gokarna','Type of hotel': 'five star','Number of days': '1','Budget': '10000'}}
            {delimiter}

            Here is the input {response}

            """
    response = openai.Completion.create(
        model="gpt-3.5-turbo-instruct",
        prompt=prompt,
        max_tokens = 2000
        # temperature=0.3,
        # top_p=0.4
    )
    return response["choices"][0]["text"]



def extract_dictionary_from_string(string):
    regex_pattern = r"\{[^{}]+\}"

    dictionary_matches = re.findall(regex_pattern, string)

    # Extract the first dictionary match and convert it to lowercase
    if dictionary_matches:
        dictionary_string = dictionary_matches[0]
        dictionary_string = dictionary_string.lower()

        # Convert the dictionary string to a dictionary object using ast.literal_eval()
        dictionary = ast.literal_eval(dictionary_string)
    return dictionary




def compare_destination_with_user(user_req_string):
    destination_df= pd.read_csv('updated_Travelinfo.csv')
    user_requirements = extract_dictionary_from_string(user_req_string)
    budget = int(user_requirements.get('budget', '0').replace(',', '').split()[0])
    #This line retrieves the value associated with the key 'budget' from the user_requirements dictionary.
    #If the key is not found, the default value '0' is used.
    #The value is then processed to remove commas, split it into a list of strings, and take the first element of the list.
    #Finally, the resulting value is converted to an integer and assigned to the variable budget.


    filtered_destination = destination_df.copy()
    filtered_destination['Price'] = filtered_destination['Price'].str.replace(',','').astype(int)
    filtered_destination = filtered_destination[filtered_destination['Price'] <= budget].copy()
    #These lines create a copy of the destination_df DataFrame and assign it to filtered_destinations.
    #They then modify the 'Price' column in filtered_destinations by removing commas and converting the values to integers.
    #Finally, they filter filtered_destinations to include only rows where the 'Price' is less than or equal to the budget.

    mappings = {
        'low': 0,
        'medium': 1,
        'high': 2

    }
    # Create 'Score' column in the DataFrame and initialize to 0
    filtered_destination['Score'] = 0
    for index, row in  filtered_destination.iterrows():
        user_product_match_str = row['destination_feature']
        destination_values = extract_dictionary_from_string(user_product_match_str)
        score = 0

        for key, user_value in user_requirements.items():
            if key.lower() == 'budget':
                continue  # Skip budget comparison
            destination_value = destination_values.get(key, None)
            destination_mapping = mappings.get(destination_value.lower(), -1)
            user_mapping = mappings.get(user_value.lower(), -1)
            if destination_mapping >= user_mapping:
             
                score += 1

        filtered_destination.loc[index, 'Score'] = score

    # Sort the destinations by score in descending order and return the top 5 products
    top_destinations = filtered_destination.drop('destination_feature', axis=1)
    top_destinations = top_destinations.sort_values('Score', ascending=False).head(5)

    return top_destinations.to_json(orient='records')




def recommendation_validation(destination_recommendation):
    data = json.loads(destination_recommendation)
    data1 = []
    for i in range(len(data)):
        if data[i]['Score'] > 2:
            data1.append(data[i])

    return data1




def initialize_conv_reco(hotels):
    system_message = f"""
    You are an intelligent travel planner  and you are tasked with the objective to \
    solve the user queries about any destination from the catalogue: {hotels}.\
    You should keep the user profile in mind while answering the questions.\

    Start with a brief summary of each laptop in the following format, in decreasing order of price of laptops:
    1. <Hotel Name> : <Major specifications of the hotel for a destination >, <Price in Rs>
    2. <<Hotel Name> : <Major specifications of the hotel for a destination >, <Price in Rs>

    """
    conversation = [{"role": "system", "content": system_message }]
    return conversation
