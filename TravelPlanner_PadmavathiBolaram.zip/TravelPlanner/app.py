from flask import Flask, redirect, url_for, render_template, request
from functions import initialize_conversation, initialize_conv_reco, get_chat_model_completions, moderation_check,intent_confirmation_layer,dictionary_present,compare_destination_with_user,recommendation_validation

import openai
import ast
import re
import pandas as pd
import json
import time

openai.api_key = open("api_key.txt", "r").read().strip()

app = Flask(__name__)

conversation_bot = []
conversation = initialize_conversation()
introduction = get_chat_model_completions(conversation)
conversation_bot.append({'bot':introduction})
top_5_hotels = None


@app.route("/")
def default_func():
    global conversation_bot, conversation, top_5_hotels
    return render_template("index_invite.html", name_xyz = conversation_bot)

@app.route("/end_conv", methods = ['POST','GET'])
def end_conv():
    global conversation_bot, conversation, top_5_hotels
    conversation_bot = []
    conversation = initialize_conversation()
    introduction = get_chat_model_completions(conversation)
    conversation_bot.append({'bot':introduction})
    top_5_hotels = None
    return redirect(url_for('default_func'))

@app.route("/invite", methods = ['POST'])
def invite():
    global conversation_bot, conversation, top_5_hotels, conversation_reco
    user_input = request.form["user_input_message"]
    time.sleep(21)
    prompt = 'Remember your system message and that ou are a travel iternary planner. So, you only help with questions around travel itenery,best hotels in a given destination for given days.'
    moderation = moderation_check(user_input)
    time.sleep(21)
    
    if moderation == 'Flagged':
        return redirect(url_for('end_conv'))

    if top_5_hotels is None:
        conversation.append({"role": "user", "content": user_input + prompt})
        conversation_bot.append({'user':user_input})
      

        response_assistant = get_chat_model_completions(conversation)
        time.sleep(21)
       # 
    else:
        conversation_reco.append({"role": "user", "content": user_input})
        conversation_bot.append({'user':user_input})

        response_asst_reco = get_chat_model_completions(conversation_reco)
        time.sleep(21)
        moderation = moderation_check(response_asst_reco)
        if moderation == 'Flagged':
            return redirect(url_for('end_conv'))
        conversation.append({"role": "assistant", "content": response_asst_reco})
        conversation_bot.append({'bot':response_asst_reco})
    return redirect(url_for('default_func'))

if __name__ == '__main__':
    app.run(debug=True, host= "0.0.0.0")